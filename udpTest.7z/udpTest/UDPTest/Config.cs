﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace UDPTest
{
   public class Config
    {
        private byte[] sendData;
        private string recData;
        private int sleep;
        private IPEndPoint repoint;
        private IPEndPoint lopoint;
        private bool isMCS = false;
        public IPEndPoint LoPoint
        {
            get { return lopoint; }
            set { lopoint = value; }
        }
        public IPEndPoint RePoint
        {
            get { return repoint; }
            set { repoint = value; }
        }
        public byte[] SendData
        {
            get { return sendData; }
            set { sendData = value; }
        }
        public string RecData
        {
            get { return recData; }
            set { recData = value; }
        }
        public int Sleep
        {
            get { return sleep; }
            set
            {
                if (value < 0) value = 0;
                sleep = value;
            }
        }

        public bool IsMCS { get => isMCS; set => isMCS = value; }

        public static List<Config> Configs;
        public static string filePath =Application.StartupPath+ "\\Config.xml";
        /// <summary>
        /// 加载配置文件
        /// </summary>
        public static void LoadFile()
        {
            Configs = new List<Config>();
            if (File.Exists(filePath))
            {
                XmlDocument myDoc = new XmlDocument();
                try
                {
                    myDoc.Load(filePath);
                    XmlElement xe = myDoc.DocumentElement;
                    foreach (XmlNode node in xe.ChildNodes)
                    {
                        if (!node.Name.Contains("Config")) continue;
                        Config config = new Config();
                        foreach (XmlNode node1 in node.ChildNodes)
                        {
                            switch (node1.Name)
                            {
                                case "RecData":
                                    config.RecData = node1.FirstChild.Value;
                                    break;
                                case "SendData":
                                    string[] sendData = node1.FirstChild.Value.Trim().Split(',');
                                    List<byte> temp = new List<byte>();
                                    foreach (string data in sendData)
                                    {
                                        if(!string.IsNullOrEmpty(data))
                                        temp.Add(Convert.ToByte(data, 16));
                                    }
                                    config.SendData = temp.ToArray();
                                    break;
                                case "Sleep":
                                    config.Sleep = int.Parse(node1.FirstChild.Value);
                                    break;
                            }
                        }
                        Configs.Add(config);
                    }
                }
                catch(Exception ex)
                { }
            }
        }
        /// <summary>
        /// 保存配置到文件
        /// </summary>
        public static void SaveFile()
        {
            if (Configs == null) Configs = new List<Config>();
                try
                {
                    XmlDocument myDoc = new XmlDocument();
                    XmlElement  xe = myDoc.CreateElement("Config");
                    myDoc.AppendChild(xe);
                    int index = 1;
                    foreach (Config config in Configs)
                    {
                       XmlElement xep = myDoc.CreateElement("Config" + index.ToString());

                        XmlElement xe1 = myDoc.CreateElement("RecData");
                        XmlText xt1 = myDoc.CreateTextNode(config.RecData);

                        XmlElement xe2 = myDoc.CreateElement("SendData");
                        StringBuilder sb = new StringBuilder();
                        foreach (byte b in config.SendData)
                            sb.Append(b.ToString("x2") + ",");//发送数据保存格式为：43,fd,32,ff,ab,
                        XmlText xt2 = myDoc.CreateTextNode(sb.ToString());

                        XmlElement xe3 = myDoc.CreateElement("Sleep");
                        XmlText xt3 = myDoc.CreateTextNode(config.Sleep.ToString());

                        xep.AppendChild(xe1);
                        xep.LastChild.AppendChild(xt1);
                        xep.AppendChild(xe2);
                        xep.LastChild.AppendChild(xt2);
                        xep.AppendChild(xe3);
                        xep.LastChild.AppendChild(xt3);

                        xe.AppendChild(xep);

                        index++;
                    }
                    myDoc.Save(filePath);
                }
                catch(Exception ex)
                {
                throw new Exception(ex.Message,ex);
            }
        }
        /// <summary>
        /// 更新元素配置
        /// </summary>
        /// <param name="b"></param>
        /// <param name="data"></param>
        /// <param name="sleep"></param>
        public static void UpdateConfig(string b,byte[] data,int sleep)
        {
            if (Configs == null) Configs = new List<Config>();//判断配置集合是否初始化
            bool flag = false;//原先是否存在元素
            foreach (Config config in Configs)
            {
                if (config.RecData == b)//标志字节是否相等，相等则存在
                {
                    config.SendData = data;
                    config.Sleep = sleep;
                    flag=true;
                    break;
                }
            }
            if (!flag)
            {
                Config config = new Config() { RecData=b,SendData=data,Sleep=sleep};
                Configs.Add(config);
            }
            //保存配置列表
            Config.SaveFile();
        }

        /// <summary>
        /// 是否包含配置
        /// </summary>
        /// <param name="rec"></param>
        /// <returns></returns>
        public static Config GetConfig(string rec)
        {
            if (Configs == null) return null;
            foreach (Config config in Configs)
            {
                if (Regex.IsMatch(rec, config.RecData)) return config;
            }
            return null;
        }
    }

}
