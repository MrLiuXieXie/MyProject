﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace UDPTest
{
    public class XMLrw
    {
        private string name;

        public string Name
        {
            get;
            set;
        } = "liu";

        public static void WriteXML(string path, string name, string value)
        {
            XmlDocument myDoc = new XmlDocument();
            myDoc.Load(path);
            XmlElement xe = (XmlElement) myDoc.SelectSingleNode("PortName");
            xe.GetAttribute("Name");
            xe.InnerText = "";
            xe.SetAttribute("name", "Name");
        }

        //
        //{
        //    "CAN": false,
        //    "AccCode": 4294901856,
        //    "Id": 768,
        //    "BPointMove": true,
        //    "L_BPointMoveDelay": "600",
        //    "R_BPointMoveDelay": "1000"
        //}
        public static bool ReadJson(string path)
        {
            //StreamReader sr = File.OpenText(path);
            //JsonTextReader json = new JsonTextReader(sr);
            //JObject O = (JObject)JToken.ReadFrom(json);
            string json = File.ReadAllText(path);
            dynamic obj = JsonConvert.DeserializeObject(json);
            bool CAN = obj["CAN"];
            // uint AccCode = (uint) O["AccCode"];
            //...
            //  sr.Close();
            return CAN;
        }

        public static void WriteJson(string path, string name, string value)
        {
            string json = File.ReadAllText(path);
            dynamic obj = JsonConvert.DeserializeObject(json);
            obj[name] = value;
            string input = JsonConvert.SerializeObject(obj, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(path, input);
        }
        public static bool WriteJson(string path)
        {
            person p = new person();
            string input = JsonConvert.SerializeObject(p, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(path, input);
            return true;
        }
        public static string ReadJson(string path, string name)
        {
            string json = File.ReadAllText(path);
            dynamic obj = JsonConvert.DeserializeObject(json);
           person p= obj as person;
           if (p != null)
               return p.name;
            return obj["name"];
        }
        public class person
        {
            public string name = "liu";
            public int age = 28;
            public int[] ages = {1, 2, 3, 4};
            public string[] names = { "li","xi"};
            public List<string> strs = new List<string>() { "qi","gui"};
        }

    }
}
