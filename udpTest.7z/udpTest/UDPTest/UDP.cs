﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace UDPTest
{
   public class UDP:IUdp
    {
        IPEndPoint remotePoint;
        IPEndPoint localPoint;
        UdpClient localUDP;
        Thread thread;

        public IPEndPoint LocalPoint { get => localPoint; set => localPoint = value; }
        public IPEndPoint RemotePoint { get => remotePoint; set => remotePoint = value; }

        public event EventHandler<DataArgs> ReceiveMessage;

        public UDP(IPEndPoint remotePoint, IPEndPoint localPoint)
        {
            this.RemotePoint = remotePoint;
            this.LocalPoint = localPoint;
             localUDP = new UdpClient(localPoint);
        }
        public void Listen()
        {
            if (thread == null|| !thread.IsAlive)
            {
                thread = new Thread(deal);
                thread.IsBackground = true;
            }
            if (!thread.IsAlive)
            {
                thread.Start();
            }
        }

        public void deal()
        {
            IPEndPoint Point = new IPEndPoint(IPAddress.Any, 0);
            while (true)
            {
                try
                {
                    byte[] data = localUDP.Receive(ref Point);
                    RemotePoint = Point;
                    if (ReceiveMessage != null)
                        ReceiveMessage(this,new DataArgs(data,RemotePoint,this.LocalPoint));
                }
                catch
                { }
            }
        }



        public void Stop()
        {
            if (thread != null && thread.IsAlive) thread.Abort();
            localUDP?.Dispose();
        }
        public  void Send(byte[] datas,IPEndPoint point)
        {
            if (localUDP != null)
            {
                localUDP.Send(datas, datas.Length, point);
                return;
            }
            using (UdpClient udpSend = new UdpClient(0))
            {
                udpSend.Send(datas, datas.Length, point);
                udpSend.Dispose();
            }
        }
    }

   public interface IUdp
   {
       void Send(byte[] datas, IPEndPoint point);
       void Stop();
       void deal();
       void Listen();
   }

   public class DataArgs : EventArgs
    {
        public byte[] Data;
        public IPEndPoint rePoint;
        public IPEndPoint loPoint;
        public DataArgs(byte[] Data,IPEndPoint remotepoint, IPEndPoint localpoint)
        {
            this.Data = Data;
            this.rePoint = remotepoint;
            this.loPoint = localpoint;
        }
    }
}
