﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UDPTest
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
            CS.Add(ucDef);
        }
        UDP server;
        Config temp;
        StringBuilder sb = new StringBuilder();
        StringBuilder sbShow = new StringBuilder();
        List<UC_Config> CS = new List<UC_Config>();
        int x = 9;
        int y = 24;
        byte[] needSendData;

        /// <summary>
        /// 初始化
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmMain_Load(object sender, EventArgs e)
        {
            Config.LoadFile();
            foreach (IPAddress IP in Dns.GetHostAddresses(Dns.GetHostName()))
            {
                if (IP.AddressFamily.ToString() == "InterNetwork")
                {
                    cmbLocalIP.Items.Add(IP.ToString());
                    txtRemoteIP.Text = IP.ToString();
                }
            }
            cmbLocalIP.Items.Add("127.0.0.1");
            cmbLocalIP.SelectedIndex = 0;
            LoadDgv();
            x = ucDef.Location.X;
            y = ucDef.Location.Y;
        }

        /// <summary>
        /// 启动或关闭
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnStart_Click(object sender, EventArgs e)
        {
            if (btnStart.Text == "启 动")
            {
                if (server != null) server.Stop();
                string remoteIP = txtRemoteIP.Text.Trim();
                string remotePort = txtRemotePort.Text.Trim();
                string localIP = cmbLocalIP.Text.Trim();
                string localPort = txtLocalPort.Text.Trim();
                IPEndPoint LocalPoint =null;
                IPEndPoint RemotePoint =null;
                if (!string.IsNullOrEmpty(remoteIP) &&! string.IsNullOrEmpty(remotePort)&& remotePort!="0")
                {
                    
                    RemotePoint = new IPEndPoint(IPAddress.Parse(remoteIP), int.Parse(remotePort));
                }  
                if (string.IsNullOrEmpty(localIP) || string.IsNullOrEmpty(localPort))
                {
                    MessageBox.Show("配置错误！","配置提示",MessageBoxButtons.OK,MessageBoxIcon.Error);
                    return;
                }
                try
                {
                    LocalPoint = new IPEndPoint(IPAddress.Parse(localIP), int.Parse(localPort));
                    server = new UDP(RemotePoint, LocalPoint);
                    server.ReceiveMessage += new EventHandler<DataArgs>(recData);
                    server.Listen();
                    btnStart.Text = "关 闭";
                    btnStart.BackColor = Color.SpringGreen;
                    SetEnable(false);
                }
                catch(Exception ex)
                {
                    MessageBox.Show("启动失败！", "启动提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                if (server != null)
                {
                    server.Stop();
                }
                btnStart.Text = "启 动";
                btnStart.BackColor = Color.Linen;
                SetEnable(true);
            }
        }

        public void SetEnable(bool enable)
        {
            txtRemoteIP.Enabled = enable;
            txtRemotePort.Enabled = enable;
            cmbLocalIP .Enabled = enable;
            txtLocalPort.Enabled = enable;
        }
        /// <summary>
        /// 加载配置列表
        /// </summary>
        public void LoadDgv()
        {
            try
            {
                dgvList.Rows.Clear();
                if (Config.Configs != null)
                {
                    foreach (Config config in Config.Configs)
                    {
                        SetString(sb, config);
                        object[] data = new object[] { config.RecData, config.Sleep.ToString(), sb.ToString() };
                        int index = dgvList.Rows.Add(data);
                        dgvList.Rows[index].Tag = config;
                    }
                }
            }
            catch
            {
                throw;
            }
        }
        /// <summary>
        /// 设置字符串
        /// </summary>
        /// <param name="sb"></param>
        /// <param name="config"></param>
        private void SetString(StringBuilder sb, Config config)
        {
            sb.Clear();
            foreach (byte b in config.SendData)
                sb.Append(b.ToString("x2").PadLeft(2, '0').ToUpper() + ",");
        }
        /// <summary>
        /// 解析数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void recData(object sender, DataArgs e)
        {
            try
            {
                // DataPackage package = DataPackage.CreatePackFromData(e.Data);
                // if (package == null) return;
                // if (package.IsMCS == chbLocalisMCS.Checked) return;//如果接收到的包与选项不符，则直接返回
                string message = GetStringFromBytes(e.Data);
                AppendText(e.rePoint, message, true);
                Config config= Config.GetConfig(message);
                if (config == null) return;
                config.RePoint = e.rePoint;
                config.LoPoint = e.loPoint;
               // config.IsMCS = !package.IsMCS;//与发送过来数据相反 
                if (config != null)
                {
                    ParameterizedThreadStart threadStart = new ParameterizedThreadStart(SendData);
                    Thread thread = new Thread(threadStart);
                    thread.IsBackground = true;
                    thread.Start(config);
                }
            }
             catch(Exception ex)
            {
              //  MessageBox.Show("数据接收失败！", "发送数据提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 根据字节数组生成字符串
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private string GetStringFromBytes(byte[] data)
        {
            if (data == null) return "";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < data.Length; i++)
            {
                sb.Append(data[i].ToString("x2").PadLeft(2,'0').ToUpper());
            }
            return sb.ToString();
        }

        /// <summary>
        /// 发送数据
        /// </summary>
        /// <param name="o"></param>
        private void SendData(object o)
        {
            Config config = o as Config;
            if (config != null)
            {
                Thread.Sleep(config.Sleep);
                try
                {
                    server.Send(config.SendData, config.RePoint);
                    AppendText(server.LocalPoint, GetStringFromBytes(config.SendData), false);
                }
                catch
                {
                    MessageBox.Show("发送失败！", "发送数据提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        /// <summary>
        /// 追加信息
        /// </summary>
        /// <param name="point"></param>
        /// <param name="sendData"></param>
        /// <param name="v"></param>
        private void AppendText(IPEndPoint point, string Data, bool isRec)
        {
            if (this.InvokeRequired)
            {
                Action<IPEndPoint, string, bool> del = AppendText;
                this.Invoke(del,point,Data,isRec);
                return;
            }
            string s = isRec ? "->" : "<-";
             string message = string.Join(" ", System.Text.RegularExpressions.Regex.Split(Data, "(?<=\\G.{2})(?!$)"));
            lbData.BeginUpdate();
            if(lbData.Items.Count>1000) lbData.Items.Clear();
            lbData.Items.Insert(0, string.Format("[{0}][{1}]{2} {3}", point.ToString(), DateTime.Now.ToString("HH:mm:ss"), s, message));
            lbData.SelectedIndex = 0;
            lbData.EndUpdate();
        }

        /// <summary>
        /// 设置配置显示
        /// </summary>
        /// <param name="config"></param>
        private void SetConfigShow(Config config)
        {
            txtCmd.Text = "";
            txtSleep.Text = "";
            txtData.Text = "";
            txtDataLength.Text = "";
            string data = "";
            if (config != null)
            {
                data = config.RecData;
                txtSleep.Text = config.Sleep.ToString();
                SetString(sb, config);
                txtData.Text = sb.ToString();
                txtDataLength.Text = config.SendData.Length.ToString();
            }
            txtCmd.Text = data;
           if(data.Length>2) data = data.Substring(1,data.Length-2);
            //解析条件 ^\w{0}67\w{12}54  0}65 12}54
            if (!string.IsNullOrEmpty(txtCmd.Text))
            {
                try
                {
                    string[] regex = data.Replace("\\w{", " ").Trim().Split(' ');
                    int index = Math.Abs(CS.Count - regex.Length);
                    if (regex.Length < CS.Count)
                    {
                        for(int i=0;i< index; i++)
                            RemoveControl();

                    }
                    else if (regex.Length > CS.Count)
                    {
                        for (int i = 0; i < index; i++)
                            AddControl();
                    }
                    index = 9;
                    int ind = 0;
                    for (int j=0;j<regex.Length;j++)
                    {
                        string[] v = regex[j].Split('}');
                        foreach (UC_Config u in CS)
                        {
                            if (index == u.Location.X)
                            {
                                ind = u.SetValue(v, ind);
                            }
                        }
                        index += 100;
                    }
                }
                catch(Exception ex)
                { }
            }
        }

        /// <summary>
        /// 删除一条配置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("确定删除本条配置吗？", "删除提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (Config.Configs != null && temp != null)
                    Config.Configs.Remove(temp);
                Config.SaveFile();
                LoadDgv();
                SetConfigShow();
            }
        }

        /// <summary>
        /// 增加一条配置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtCmd.Text) || string.IsNullOrEmpty(txtSleep.Text) || string.IsNullOrEmpty(txtData.Text))
            {
                MessageBox.Show("输入错误！","输入提示",MessageBoxButtons.OK,MessageBoxIcon.Error);
                return;
            }
            string rec= txtCmd.Text.Trim();
            byte[] data;
            int sleep;
            try
            {
                if (Config.GetConfig(rec)!=null)
                {
                    MessageBox.Show("已存在，不可添加！", "添加提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }
                string[] datas = txtData.Text.Trim().Split(',');
               if(datas.Contains("")) data = new byte[datas.Length-1];
               else data = new byte[datas.Length];
                int index = 0;
                foreach (string s in datas)
                {
                    if(!string.IsNullOrEmpty(s))
                    data[index++]= Convert.ToByte(s.Trim(), 16);
                }
                sleep = Convert.ToInt32(txtSleep.Text.Trim());
                Config config = new Config();
                config.RecData = rec;
                config.SendData = data;
                config.Sleep = sleep;
                Config.Configs.Add(config);
                Config.SaveFile();
                LoadDgv();
                SetConfigShow();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// 更新一条配置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (temp == null)
            {
                MessageBox.Show("当前未选择配置！", "选择提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (string.IsNullOrEmpty(txtCmd.Text) || string.IsNullOrEmpty(txtSleep.Text) || string.IsNullOrEmpty(txtData.Text))
            {
                MessageBox.Show("输入错误！", "输入提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string rec=txtCmd.Text.Trim();
            byte[] data;
            int sleep;
            try
            {
                string[] datas = txtData.Text.Trim().Split(',');
                data = new byte[datas.Length-1];
                int index = 0;
                foreach (string s in datas)
                {
                    if (!string.IsNullOrEmpty(s))
                    data[index++] = Convert.ToByte(s.Trim(), 16);
                }
                sleep = Convert.ToInt32(txtSleep.Text.Trim());
                temp.RecData = rec;
                temp.SendData = data;
                temp.Sleep = sleep;
                Config.SaveFile();
                LoadDgv();
                SetConfigShow();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        /// <summary>
        /// 随机生成
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRand_Click(object sender, EventArgs e)
        {
            txtData.Text = "";
            int length = 5;
            int.TryParse(txtDataLength.Text.Trim(), out length);
            if (length <= 0) length = 5;
            txtData.Text = GetData(length);
            txtDataLength.Text = length.ToString();
        }

        /// <summary>
        /// 随机生成的字节数组格式化为字符串
        /// </summary>
        /// <param name="count"></param>
        /// <returns></returns>
        private string GetData(int count)
        {
            Random rand = new Random();
            StringBuilder s = new StringBuilder();
            for(int i=0;i<count;i++)
             s.Append(rand.Next(1, 255).ToString("x2").PadLeft(2,'0').ToUpper()+",");
            return s.ToString();
        }

        private void dgvList_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            SetConfigShow();
        }

        /// <summary>
        /// 显示单条配置
        /// </summary>
        private void SetConfigShow()
        {
            if (dgvList.SelectedRows.Count > 0)
                temp = dgvList.SelectedRows[0].Tag as Config;
            else
                temp = null;
            SetConfigShow(temp);
        }
       
        /// <summary>
        /// 发送数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                needSendData = GetData(txtSend.Text.Trim());
                if (needSendData == null)
                {
                    MessageBox.Show("发送失败！输入格式错误", "发送数据提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                if (server != null)
                {
                    server.Send(needSendData, new IPEndPoint(IPAddress.Parse(txtRemoteIP.Text.Trim()), int.Parse(txtRemotePort.Text.Trim())));
                    AppendText(server.LocalPoint, GetStringFromBytes(needSendData), false);
                }
                else
                    MessageBox.Show("发送失败！网络未打开", "发送数据提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch
            {
                MessageBox.Show("发送失败！网络未打开或者输入错误", "发送数据提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 字符串格式化成字节数组
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        private byte[] GetData(string message)
        {
            if (string.IsNullOrEmpty(message))
            {
                return null;
            }
            try
            {
                string[] datas = txtSend.Text.Trim().Split(' ');
                List<byte> sendDatas = new List<byte>();
                for (int i = 0; i < datas.Length; i++)
                {
                    if ((datas[i].Length % 2) != 0) datas[i] += "0";
                        for (int j = 0; j < datas[i].Length; j+=2)
                        {
                            sendDatas.Add(Convert.ToByte(datas[i].Substring(j, 2), 16));
                        }
                }
                return sendDatas.ToArray();
            }
            catch
            {
                return null;
            }
        }

        private void chbLocalisMCS_Click(object sender, EventArgs e)
        {
            chbLocalisCDS.Checked = false;
            chbLocalisMCS.Checked = true;
        }

        private void chbLocalisCDS_Click(object sender, EventArgs e)
        {
            chbLocalisCDS.Checked = true;
            chbLocalisMCS.Checked = false;
        }

        private void chbMCSSend_Click(object sender, EventArgs e)
        {
            chbMCSSend.Checked = true;
            chbCDSSend.Checked = false;
        }

        private void chbCDSSend_Click(object sender, EventArgs e)
        {
            chbMCSSend.Checked = false;
            chbCDSSend.Checked = true;
        }

        private void 清空ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lbData.Items.Clear();
        }

        /// <summary>
        /// 打开定时发送数据开关
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chbTime_CheckedChanged(object sender, EventArgs e)
        {
            timer.Stop();
            int span = 0;
            if (chbTime.Checked)
            {
                if (int.TryParse(txtTimeSpan.Text.Trim(), out span))
                {
                    if (span <= 0)
                    {
                        MessageBox.Show("间隔不能为负！", "输入提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    if (chbTime.Checked)
                    {
                        needSendData = GetData(txtSend.Text.Trim());
                        timer.Interval = span;
                        timer.Start();
                        txtTimeSpan.Enabled = false;
                        txtSend.Enabled = false;
                    }
                    else
                    {
                        txtTimeSpan.Enabled = true;
                        txtSend.Enabled = true;
                    }
                }
                else
                {
                    MessageBox.Show("时间间隔输入错误！", "输入提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                txtTimeSpan.Enabled = true;
                txtSend.Enabled = true;
            }
        }

        /// <summary>
        /// 定时发送数据
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer_Tick(object sender, EventArgs e)
        {
            try
            {
                if (needSendData == null) return;
                if (server != null)
                {
                    server.Send(needSendData, new IPEndPoint(IPAddress.Parse(txtRemoteIP.Text.Trim()), int.Parse(txtRemotePort.Text.Trim())));
                    AppendText(server.LocalPoint, GetStringFromBytes(needSendData), false);
                }
            }
            catch
            {
               // MessageBox.Show("发送失败！", "发送数据提示", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// 窗体关闭前事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("您确定关闭工具吗？", "关闭提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
                return;
            }
        }

        /// <summary>
        /// 计算正则表达式，并显示
        /// </summary>
        public void CalculExpress()
        {
            if (this.InvokeRequired)
            {
                Action del = CalculExpress;
                this.Invoke(del);
                return;
            }
            CS.Sort();
            sbShow.Clear();
            //拼接正则表达式
            for (int i = 0; i < CS.Count; i++)
            {
                //\w{index}data
                int index = CS[i].Index;
                if(i>0) index = CS[i].Index - CS[i - 1].Index;//
                if(index> 0&&CS[i].Data!="00") sbShow.Append("\\w{"+((index-1)*2).ToString()+"}"+ CS[i].Data);
            }
            if (sbShow.Length > 0)
            {
                sbShow.Insert(0, "^");
                sbShow.Append("$");
            }
            txtCmd.Text = sbShow.ToString();
        }

        private void ucDef_TxtChange(object sender, EventArgs e)
        {
            CalculExpress();
        }

        private void btnAddRegex_Click(object sender, EventArgs e)
        {
            AddControl();
        }

        /// <summary>
        /// 增加一个回包条件，如果大于6个条件，则不增加
        /// </summary>
        private void AddControl()
        {
            if (CS.Count > 5) return;
            UC_Config uC = new UC_Config();
            uC.TxtChange += ucDef_TxtChange;
            CS.Add(uC);
            x += 100;
            uC.Location = new Point(x, y);
            gbRegex.Controls.Add(uC);
            pl.Location = new Point(pl.Location.X + 100, pl.Location.Y);
        }

        private void btnRemoveRegex_Click(object sender, EventArgs e)
        {
            RemoveControl();
        }
        /// <summary>
        /// 移除一个回包条件，如果只有一个，则不移除
        /// </summary>
        private void RemoveControl()
        {
            if (CS.Count == 1) return;
            UC_Config uC = null;
            foreach (UC_Config u in CS)
            {
                if (u.Location.X >= x)
                {
                    uC = u;
                    break;
                }
            }
            if (uC != null)
            {
                uC.TxtChange -= ucDef_TxtChange;
                gbRegex.Controls.Remove(uC);
                CS.Remove(uC);
                x -= 100;
                pl.Location = new Point(pl.Location.X - 100, pl.Location.Y);
                CalculExpress();
            }
        }
    }
}
