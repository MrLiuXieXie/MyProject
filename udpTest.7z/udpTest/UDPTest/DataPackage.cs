﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UDPTest
{
   public class DataPackage
    {
        /// <summary>
        /// 包头MCS=>CDS
        /// </summary>
        public static readonly byte[] MTOC = new byte[4] { Convert.ToByte('M'), Convert.ToByte('T'), Convert.ToByte('O'), Convert.ToByte('C') };
        /// <summary>
        /// CDS=>MCS
        /// </summary>
        public static readonly byte[] CTOM = new byte[4] { Convert.ToByte('C'), Convert.ToByte('T'), Convert.ToByte('O'), Convert.ToByte('M') };

        private byte lengthL;
        private byte lengthH;
        private byte cmd;
        private List<byte> data=new List<byte>();
        private byte crcL;
        private byte crcH;
        private bool isMCS = false;
        private string errorMessage = "";

        /// <summary>
        /// 数据包长度，低八位
        /// </summary>
        public byte LengthL
        {
            get
            {
                return lengthL;
            }
            set
            {
                lengthL = value;
            }
        }

        /// <summary>
        /// 数据包长度，高八位
        /// </summary>
        public byte LengthH
        {
            get
            {
                return lengthH;
            }
            set
            {
                lengthH = value;
            }
        }
        /// <summary>
        /// 数据包Cmd
        /// </summary>
        public byte Cmd { get { return cmd; } set { cmd = value; } }
        /// <summary>
        /// 数据包数据
        /// </summary>
        public List<byte> Data
        {
            get
            {
                return data;
            }
            set
            {
                data = value;
            }
        }
        public byte CRCL { get => crcL; set => crcL = value; }
        public byte CRCH { get => crcH; set => crcH = value; }
        /// <summary>
        /// 错误消息
        /// </summary>
        public string ErrorMessage { get => errorMessage; set => errorMessage = value; }
        /// <summary>
        /// 是否为MCS数据
        /// </summary>
        public bool IsMCS { get => isMCS; set => isMCS = value; }


        /// <summary>
        /// 根据数据生成数据包
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public  static DataPackage CreatePackFromData(byte[] data)
        {
            if (data == null || data.Length < 9) return null;
            DataPackage pack = new DataPackage();
            if (data[0] == 'C' && data[3] == 'M')
                pack.IsMCS = false;
            else if(data[0] == 'M' && data[3] == 'C')
                pack.IsMCS = true;
            pack.lengthL = data[4];
            pack.LengthH = data[5];
            pack.Cmd = data[6];
            byte[] datas=new byte[data.Length - 8];
            Array.Copy(data,6,datas,0,data.Length-8);
            pack.Data = datas.ToList();
            pack.CRCL = data[data.Length - 2];
            pack.CRCH = data[data.Length - 1];
            byte[] crc = CRC16(datas);
            if (crc[0] != pack.CRCL || crc[1] != pack.CRCH)
            {
                pack.ErrorMessage = "校验错误";
            }
            return pack;
        }

        /// <summary>
        /// CRC16校验
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        public static byte[] CRC16(byte[] data)
        {
            int len = data.Length;
            if (len > 0)
            {
                ushort crc = 0xFFFF;

                for (int i = 0; i < len; i++)
                {
                    crc = (ushort)(crc ^ (data[i]));
                    for (int j = 0; j < 8; j++)
                    {
                        crc = (crc & 1) != 0 ? (ushort)((crc >> 1) ^ 0xA001) : (ushort)(crc >> 1);
                    }
                }
                byte hi = (byte)((crc & 0xFF00) >> 8); //高位置
                byte lo = (byte)(crc & 0x00FF); //低位置

                return new byte[] { hi, lo };
            }
            return new byte[] { 0, 0 };
        }

        /// <summary>
        /// 组合数据包
        /// </summary>
        /// <param name="sendDatas"></param>
        /// <param name="isMCS"></param>
        /// <returns></returns>
        public static byte[] GetData(byte[] sendDatas, bool isMCS)
        {
            List<byte> datas = new List<byte>();
            if (isMCS)
                datas.AddRange(MTOC);
            else
                datas.AddRange(CTOM);
            datas.Add((byte)(sendDatas.Length>>8));
            datas.Add((byte)(sendDatas.Length &0xFF));
            datas.AddRange(sendDatas);
            datas.AddRange(CRC16(datas.ToArray()));
            return datas.ToArray();
        }
    }
}
