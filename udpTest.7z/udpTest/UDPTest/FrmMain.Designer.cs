﻿namespace UDPTest
{
    partial class FrmMain
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chbLocalisCDS = new System.Windows.Forms.CheckBox();
            this.chbLocalisMCS = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbLocalIP = new System.Windows.Forms.ComboBox();
            this.txtRemoteIP = new System.Windows.Forms.TextBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.txtRemotePort = new System.Windows.Forms.TextBox();
            this.txtLocalPort = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnSendData = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.lbData = new System.Windows.Forms.ListBox();
            this.cmstrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.清空ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtData = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txtDataLength = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnRand = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.btnRemove = new System.Windows.Forms.Button();
            this.txtSleep = new System.Windows.Forms.TextBox();
            this.gbRegex = new System.Windows.Forms.GroupBox();
            this.pl = new System.Windows.Forms.Panel();
            this.btnAddRegex = new System.Windows.Forms.Button();
            this.btnRemoveRegex = new System.Windows.Forms.Button();
            this.ucDef = new UDPTest.UC_Config();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCmd = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dgvList = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.chbTime = new System.Windows.Forms.CheckBox();
            this.txtTimeSpan = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtSend = new System.Windows.Forms.TextBox();
            this.chbMCSSend = new System.Windows.Forms.CheckBox();
            this.chbCDSSend = new System.Windows.Forms.CheckBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.cmstrip.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.gbRegex.SuspendLayout();
            this.pl.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvList)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.groupBox1.Controls.Add(this.chbLocalisCDS);
            this.groupBox1.Controls.Add(this.chbLocalisMCS);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cmbLocalIP);
            this.groupBox1.Controls.Add(this.txtRemoteIP);
            this.groupBox1.Controls.Add(this.btnStart);
            this.groupBox1.Controls.Add(this.txtRemotePort);
            this.groupBox1.Controls.Add(this.txtLocalPort);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Left;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(158, 326);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // chbLocalisCDS
            // 
            this.chbLocalisCDS.AutoSize = true;
            this.chbLocalisCDS.Checked = true;
            this.chbLocalisCDS.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbLocalisCDS.Location = new System.Drawing.Point(4, 304);
            this.chbLocalisCDS.Name = "chbLocalisCDS";
            this.chbLocalisCDS.Size = new System.Drawing.Size(78, 16);
            this.chbLocalisCDS.TabIndex = 14;
            this.chbLocalisCDS.Text = "本地为CDS";
            this.chbLocalisCDS.UseVisualStyleBackColor = true;
            this.chbLocalisCDS.Visible = false;
            this.chbLocalisCDS.Click += new System.EventHandler(this.chbLocalisCDS_Click);
            // 
            // chbLocalisMCS
            // 
            this.chbLocalisMCS.AutoSize = true;
            this.chbLocalisMCS.Location = new System.Drawing.Point(82, 304);
            this.chbLocalisMCS.Name = "chbLocalisMCS";
            this.chbLocalisMCS.Size = new System.Drawing.Size(78, 16);
            this.chbLocalisMCS.TabIndex = 13;
            this.chbLocalisMCS.Text = "本地为MCS";
            this.chbLocalisMCS.UseVisualStyleBackColor = true;
            this.chbLocalisMCS.Visible = false;
            this.chbLocalisMCS.Click += new System.EventHandler(this.chbLocalisMCS_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "远程IP:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "远程端口：";
            // 
            // cmbLocalIP
            // 
            this.cmbLocalIP.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLocalIP.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbLocalIP.FormattingEnabled = true;
            this.cmbLocalIP.Location = new System.Drawing.Point(9, 144);
            this.cmbLocalIP.Name = "cmbLocalIP";
            this.cmbLocalIP.Size = new System.Drawing.Size(134, 27);
            this.cmbLocalIP.TabIndex = 10;
            // 
            // txtRemoteIP
            // 
            this.txtRemoteIP.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtRemoteIP.Location = new System.Drawing.Point(9, 32);
            this.txtRemoteIP.Name = "txtRemoteIP";
            this.txtRemoteIP.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtRemoteIP.Size = new System.Drawing.Size(134, 26);
            this.txtRemoteIP.TabIndex = 2;
            this.txtRemoteIP.Text = "192.168.1.237";
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.Linen;
            this.btnStart.FlatAppearance.BorderSize = 0;
            this.btnStart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStart.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnStart.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnStart.Location = new System.Drawing.Point(13, 245);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(130, 37);
            this.btnStart.TabIndex = 8;
            this.btnStart.Text = "启 动";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // txtRemotePort
            // 
            this.txtRemotePort.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtRemotePort.Location = new System.Drawing.Point(9, 87);
            this.txtRemotePort.Name = "txtRemotePort";
            this.txtRemotePort.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtRemotePort.Size = new System.Drawing.Size(134, 26);
            this.txtRemotePort.TabIndex = 3;
            this.txtRemotePort.Text = "5022";
            // 
            // txtLocalPort
            // 
            this.txtLocalPort.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtLocalPort.Location = new System.Drawing.Point(9, 199);
            this.txtLocalPort.Name = "txtLocalPort";
            this.txtLocalPort.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtLocalPort.Size = new System.Drawing.Size(134, 26);
            this.txtLocalPort.TabIndex = 7;
            this.txtLocalPort.Text = "5011";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(11, 183);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 12);
            this.label3.TabIndex = 5;
            this.label3.Text = "本地端口：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 129);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 12);
            this.label4.TabIndex = 4;
            this.label4.Text = "本地IP:";
            // 
            // btnSendData
            // 
            this.btnSendData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnSendData.BackColor = System.Drawing.Color.Linen;
            this.btnSendData.FlatAppearance.BorderSize = 0;
            this.btnSendData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSendData.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnSendData.Location = new System.Drawing.Point(13, 119);
            this.btnSendData.Name = "btnSendData";
            this.btnSendData.Size = new System.Drawing.Size(130, 37);
            this.btnSendData.TabIndex = 9;
            this.btnSendData.Text = "发 送";
            this.btnSendData.UseVisualStyleBackColor = false;
            this.btnSendData.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.lbData);
            this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox3.Location = new System.Drawing.Point(161, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(558, 326);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "消息";
            // 
            // lbData
            // 
            this.lbData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbData.ContextMenuStrip = this.cmstrip;
            this.lbData.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbData.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lbData.FormattingEnabled = true;
            this.lbData.HorizontalScrollbar = true;
            this.lbData.ItemHeight = 20;
            this.lbData.Location = new System.Drawing.Point(3, 17);
            this.lbData.Name = "lbData";
            this.lbData.Size = new System.Drawing.Size(552, 306);
            this.lbData.TabIndex = 0;
            // 
            // cmstrip
            // 
            this.cmstrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.清空ToolStripMenuItem});
            this.cmstrip.Name = "cmstrip";
            this.cmstrip.Size = new System.Drawing.Size(101, 26);
            // 
            // 清空ToolStripMenuItem
            // 
            this.清空ToolStripMenuItem.Name = "清空ToolStripMenuItem";
            this.清空ToolStripMenuItem.Size = new System.Drawing.Size(100, 22);
            this.清空ToolStripMenuItem.Text = "清空";
            this.清空ToolStripMenuItem.Click += new System.EventHandler(this.清空ToolStripMenuItem_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.groupBox2.Controls.Add(this.groupBox6);
            this.groupBox2.Controls.Add(this.gbRegex);
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox2.Location = new System.Drawing.Point(3, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(716, 505);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.txtData);
            this.groupBox6.Controls.Add(this.btnUpdate);
            this.groupBox6.Controls.Add(this.txtDataLength);
            this.groupBox6.Controls.Add(this.btnAdd);
            this.groupBox6.Controls.Add(this.btnRand);
            this.groupBox6.Controls.Add(this.label7);
            this.groupBox6.Controls.Add(this.btnRemove);
            this.groupBox6.Controls.Add(this.txtSleep);
            this.groupBox6.Location = new System.Drawing.Point(6, 160);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(698, 146);
            this.groupBox6.TabIndex = 18;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "回包数据";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(27, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 14;
            this.label8.Text = "数据长度：";
            // 
            // txtData
            // 
            this.txtData.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtData.Location = new System.Drawing.Point(210, 20);
            this.txtData.Multiline = true;
            this.txtData.Name = "txtData";
            this.txtData.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtData.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.txtData.Size = new System.Drawing.Size(386, 110);
            this.txtData.TabIndex = 7;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnUpdate.Location = new System.Drawing.Point(617, 60);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 33);
            this.btnUpdate.TabIndex = 12;
            this.btnUpdate.Text = "修 改";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // txtDataLength
            // 
            this.txtDataLength.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtDataLength.Location = new System.Drawing.Point(34, 48);
            this.txtDataLength.Name = "txtDataLength";
            this.txtDataLength.Size = new System.Drawing.Size(47, 23);
            this.txtDataLength.TabIndex = 15;
            this.txtDataLength.Text = "5";
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnAdd.Location = new System.Drawing.Point(617, 103);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 33);
            this.btnAdd.TabIndex = 11;
            this.btnAdd.Text = "增 加";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnRand
            // 
            this.btnRand.Location = new System.Drawing.Point(118, 45);
            this.btnRand.Name = "btnRand";
            this.btnRand.Size = new System.Drawing.Size(73, 64);
            this.btnRand.TabIndex = 13;
            this.btnRand.Text = "随机生成";
            this.btnRand.UseVisualStyleBackColor = true;
            this.btnRand.Click += new System.EventHandler(this.btnRand_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 12);
            this.label7.TabIndex = 8;
            this.label7.Text = "回包延时(ms)：";
            // 
            // btnRemove
            // 
            this.btnRemove.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnRemove.Location = new System.Drawing.Point(617, 17);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(75, 33);
            this.btnRemove.TabIndex = 10;
            this.btnRemove.Text = "删 除";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // txtSleep
            // 
            this.txtSleep.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtSleep.Location = new System.Drawing.Point(36, 94);
            this.txtSleep.Name = "txtSleep";
            this.txtSleep.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtSleep.Size = new System.Drawing.Size(47, 23);
            this.txtSleep.TabIndex = 9;
            this.txtSleep.Text = "0";
            // 
            // gbRegex
            // 
            this.gbRegex.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbRegex.Controls.Add(this.pl);
            this.gbRegex.Controls.Add(this.ucDef);
            this.gbRegex.Controls.Add(this.label5);
            this.gbRegex.Controls.Add(this.txtCmd);
            this.gbRegex.Location = new System.Drawing.Point(6, 19);
            this.gbRegex.Name = "gbRegex";
            this.gbRegex.Size = new System.Drawing.Size(698, 133);
            this.gbRegex.TabIndex = 17;
            this.gbRegex.TabStop = false;
            this.gbRegex.Text = "回包条件";
            // 
            // pl
            // 
            this.pl.Controls.Add(this.btnAddRegex);
            this.pl.Controls.Add(this.btnRemoveRegex);
            this.pl.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.pl.Location = new System.Drawing.Point(108, 25);
            this.pl.Name = "pl";
            this.pl.Size = new System.Drawing.Size(73, 62);
            this.pl.TabIndex = 10;
            // 
            // btnAddRegex
            // 
            this.btnAddRegex.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnAddRegex.Location = new System.Drawing.Point(0, 0);
            this.btnAddRegex.Name = "btnAddRegex";
            this.btnAddRegex.Size = new System.Drawing.Size(73, 28);
            this.btnAddRegex.TabIndex = 1;
            this.btnAddRegex.Text = "增加条件";
            this.btnAddRegex.UseVisualStyleBackColor = true;
            this.btnAddRegex.Click += new System.EventHandler(this.btnAddRegex_Click);
            // 
            // btnRemoveRegex
            // 
            this.btnRemoveRegex.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.btnRemoveRegex.Location = new System.Drawing.Point(0, 34);
            this.btnRemoveRegex.Name = "btnRemoveRegex";
            this.btnRemoveRegex.Size = new System.Drawing.Size(73, 28);
            this.btnRemoveRegex.TabIndex = 8;
            this.btnRemoveRegex.Text = "移除条件";
            this.btnRemoveRegex.UseVisualStyleBackColor = true;
            this.btnRemoveRegex.Click += new System.EventHandler(this.btnRemoveRegex_Click);
            // 
            // ucDef
            // 
            this.ucDef.Data = "00";
            this.ucDef.Id = 1;
            this.ucDef.Index = 50;
            this.ucDef.Location = new System.Drawing.Point(9, 24);
            this.ucDef.Name = "ucDef";
            this.ucDef.Size = new System.Drawing.Size(85, 62);
            this.ucDef.TabIndex = 9;
            this.ucDef.TxtChange += new System.EventHandler(this.ucDef_TxtChange);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 104);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(77, 12);
            this.label5.TabIndex = 7;
            this.label5.Text = "正则表达式：";
            // 
            // txtCmd
            // 
            this.txtCmd.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtCmd.Location = new System.Drawing.Point(98, 99);
            this.txtCmd.Name = "txtCmd";
            this.txtCmd.ReadOnly = true;
            this.txtCmd.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtCmd.Size = new System.Drawing.Size(498, 23);
            this.txtCmd.TabIndex = 6;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.dgvList);
            this.groupBox4.Location = new System.Drawing.Point(3, 312);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(707, 190);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "列表";
            // 
            // dgvList
            // 
            this.dgvList.AllowUserToAddRows = false;
            this.dgvList.AllowUserToDeleteRows = false;
            this.dgvList.AllowUserToResizeColumns = false;
            this.dgvList.AllowUserToResizeRows = false;
            this.dgvList.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvList.BackgroundColor = System.Drawing.Color.White;
            this.dgvList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dgvList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvList.Location = new System.Drawing.Point(3, 17);
            this.dgvList.Name = "dgvList";
            this.dgvList.ReadOnly = true;
            this.dgvList.RowHeadersVisible = false;
            this.dgvList.RowTemplate.Height = 23;
            this.dgvList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvList.Size = new System.Drawing.Size(701, 170);
            this.dgvList.TabIndex = 1;
            this.dgvList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvList_CellClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "正则表达式";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "回复延时(ms)";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column3.HeaderText = "回包数据";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(730, 537);
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox3);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox7);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(722, 511);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "测试";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.groupBox7.Controls.Add(this.chbTime);
            this.groupBox7.Controls.Add(this.txtTimeSpan);
            this.groupBox7.Controls.Add(this.label9);
            this.groupBox7.Controls.Add(this.txtSend);
            this.groupBox7.Controls.Add(this.chbMCSSend);
            this.groupBox7.Controls.Add(this.chbCDSSend);
            this.groupBox7.Controls.Add(this.btnSendData);
            this.groupBox7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox7.Location = new System.Drawing.Point(3, 329);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(716, 179);
            this.groupBox7.TabIndex = 12;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "发送数据";
            // 
            // chbTime
            // 
            this.chbTime.AutoSize = true;
            this.chbTime.Location = new System.Drawing.Point(9, 84);
            this.chbTime.Name = "chbTime";
            this.chbTime.Size = new System.Drawing.Size(72, 16);
            this.chbTime.TabIndex = 16;
            this.chbTime.Text = "定时发送";
            this.chbTime.UseVisualStyleBackColor = true;
            this.chbTime.CheckedChanged += new System.EventHandler(this.chbTime_CheckedChanged);
            // 
            // txtTimeSpan
            // 
            this.txtTimeSpan.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtTimeSpan.Location = new System.Drawing.Point(9, 48);
            this.txtTimeSpan.Name = "txtTimeSpan";
            this.txtTimeSpan.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtTimeSpan.Size = new System.Drawing.Size(78, 26);
            this.txtTimeSpan.TabIndex = 15;
            this.txtTimeSpan.Text = "1000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(77, 12);
            this.label9.TabIndex = 14;
            this.label9.Text = "发送间隔(ms)";
            // 
            // txtSend
            // 
            this.txtSend.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSend.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtSend.Location = new System.Drawing.Point(161, 18);
            this.txtSend.Multiline = true;
            this.txtSend.Name = "txtSend";
            this.txtSend.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtSend.Size = new System.Drawing.Size(549, 153);
            this.txtSend.TabIndex = 8;
            // 
            // chbMCSSend
            // 
            this.chbMCSSend.AutoSize = true;
            this.chbMCSSend.Checked = true;
            this.chbMCSSend.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbMCSSend.Location = new System.Drawing.Point(92, 58);
            this.chbMCSSend.Name = "chbMCSSend";
            this.chbMCSSend.Size = new System.Drawing.Size(66, 16);
            this.chbMCSSend.TabIndex = 11;
            this.chbMCSSend.Text = "MCS发送";
            this.chbMCSSend.UseVisualStyleBackColor = true;
            this.chbMCSSend.Visible = false;
            this.chbMCSSend.Click += new System.EventHandler(this.chbMCSSend_Click);
            // 
            // chbCDSSend
            // 
            this.chbCDSSend.AutoSize = true;
            this.chbCDSSend.Location = new System.Drawing.Point(92, 26);
            this.chbCDSSend.Name = "chbCDSSend";
            this.chbCDSSend.Size = new System.Drawing.Size(66, 16);
            this.chbCDSSend.TabIndex = 12;
            this.chbCDSSend.Text = "CDS发送";
            this.chbCDSSend.UseVisualStyleBackColor = true;
            this.chbCDSSend.Visible = false;
            this.chbCDSSend.Click += new System.EventHandler(this.chbCDSSend_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(722, 511);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "配置";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(730, 537);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UDP测试";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.cmstrip.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.gbRegex.ResumeLayout(false);
            this.gbRegex.PerformLayout();
            this.pl.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvList)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnConfig;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.TextBox txtLocalPort;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtRemotePort;
        private System.Windows.Forms.TextBox txtRemoteIP;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ListBox lbData;
        private System.Windows.Forms.ComboBox cmbLocalIP;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnRand;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.TextBox txtSleep;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtCmd;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dgvList;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button btnSendData;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox txtSend;
        private System.Windows.Forms.CheckBox chbCDSSend;
        private System.Windows.Forms.CheckBox chbMCSSend;
        private System.Windows.Forms.CheckBox chbLocalisCDS;
        private System.Windows.Forms.CheckBox chbLocalisMCS;
        private System.Windows.Forms.TextBox txtDataLength;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ContextMenuStrip cmstrip;
        private System.Windows.Forms.ToolStripMenuItem 清空ToolStripMenuItem;
        private System.Windows.Forms.CheckBox chbTime;
        private System.Windows.Forms.TextBox txtTimeSpan;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.GroupBox gbRegex;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnAddRegex;
        private System.Windows.Forms.Button btnRemoveRegex;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private UC_Config ucDef;
        private System.Windows.Forms.Panel pl;
    }
}

