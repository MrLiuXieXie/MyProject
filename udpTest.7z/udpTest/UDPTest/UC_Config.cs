﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace UDPTest
{
    public partial class UC_Config : UserControl,IComparable<UC_Config>
    {
        public UC_Config()
        {
            InitializeComponent();
        }
        private int index = 0;
        private string data = "00";
        private int id = 1;
        public event EventHandler TxtChange;
        [DisplayName("位置"),Description("在包中第几个字节,最大位置5000"),Browsable(false)]
        public int Index
        {
            get => index;
            set {
                index = value;
              
            }
        }
        [DisplayName("字符"), Description("在包中字节对应的16进制字符串"), Browsable(false)]
        public string Data
        {
            get => data;
            set
            {
                data = value;
               
            }
        }

        public int Id { get => id; set => id = value; }

        private void txtIndex_TextChanged(object sender, EventArgs e)
        {
            try
            {
                string strI = txtIndex.Text.Trim();
                if (string.IsNullOrEmpty(strI))
                {
                    Index = 0;
                }
                else
                {
                    int i;
                    if (int.TryParse(strI, out i) && i >= 0)
                    {
                        if (i < 5000)
                            Index = i;
                        else
                        {
                            i = 5000;
                            txtIndex.Text = "5000";
                            txtIndex.Select(strI.Length - 1, 0);
                        }
                        if (TxtChange != null)
                            TxtChange(this, null);
                    }
                    else
                    {
                        txtIndex.Text = strI.Substring(0,strI.Length-1);
                        txtIndex.Select(strI.Length - 1,0);
                    }
                }
            }
            catch
            { }
        }

        private void txtByte_TextChanged(object sender, EventArgs e)
        {
            string strB = txtByte.Text.Trim();
            if (string.IsNullOrEmpty(strB))
            {
                Data = "00";
            }
            else
            {
                if(strB.Length>2)
                {
                    txtByte.Text = strB.Substring(0, strB.Length - 1);
                    txtByte.SelectAll();
                }
                if (Regex.IsMatch(strB, "^[0-9A-Fa-f]{1,2}$"))
                {
                    if (strB.Length == 1) strB = strB.PadLeft(2, '0').ToUpper();
                    Data = strB;
                    if (TxtChange != null)
                        TxtChange(this, null);
                }
                else
                {
                    txtByte.Text = strB.Substring(0, strB.Length - 1);
                    txtByte.Select(strB.Length - 1, 0);
                }
            }
        }

        public int CompareTo(UC_Config other)
        {
            if (null == other) return 1;
            return this.Index.CompareTo(other.Index);
        }

        public int SetValue(string[] v,int e)
        {
            int index = int.Parse(v[0]);
            int rec = index / 2 + 1 + e;
            this.txtIndex.TextChanged -= new System.EventHandler(this.txtIndex_TextChanged);
            this.txtByte.TextChanged -= new System.EventHandler(this.txtByte_TextChanged);
            txtIndex.Text = rec.ToString();
            Index = rec;
            Data = v[1];
            txtByte.Text = v[1];
            this.txtIndex.TextChanged += new System.EventHandler(this.txtIndex_TextChanged);
            this.txtByte.TextChanged += new System.EventHandler(this.txtByte_TextChanged);
            return rec;
        }
    }
}
